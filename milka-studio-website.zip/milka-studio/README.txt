MILKA STUDIO WEBSITE

Open index.html in a browser to preview the site.

Pages:
- index.html — Home
- projects.html — Projects
- photos.html — Photos + filter + lightbox
- packages.html — Packages
- contact.html — Contact + inquiry form

Brand:
- Deep Teal #164B4D
- Slate Grey #647174
- Mist White #EEF1EF
- Basalt Black #111516
- Font: Manrope (geometric sans-serif feel) + editorial serif accent

IMPORTANT BEFORE LAUNCH:
1. Replace placeholder phone/email/social links in contact.html.
2. Replace Unsplash image URLs with Milka Studio's own licensed photos.
3. Add real package prices.
4. Connect the contact form to Formspree, Netlify Forms, a custom backend, or email service.
5. For production, host the folder on Netlify, Vercel, GitHub Pages, or another static host.
